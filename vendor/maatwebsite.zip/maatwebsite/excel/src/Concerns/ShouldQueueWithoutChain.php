<?php

namespace Maatwebsite\Excel\Concerns;

use Illuminate\Contracts\Queue\ShouldQueue;

interface ShouldQueueWithoutChain extends ShouldQueue
{
}
